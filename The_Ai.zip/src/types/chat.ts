export type MessageRole = 'user' | 'assistant';
export type GenerationType = 'text' | 'image';
export type Theme = 'light' | 'dark' | 'system';
export type FontSize = 'small' | 'medium' | 'large';
export type AnimationSpeed = 'slow' | 'normal' | 'fast';
export type ChatWidth = 'compact' | 'medium' | 'wide';
export type BubbleShape = 'rounded' | 'square';

export interface AttachedFile {
  id: string;
  file: File;
  preview?: string;
}

export interface Message {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: Date;
  type: GenerationType;
  attachments?: AttachedFile[];
  imageUrl?: string;
  provider?: string;
  model?: string;
}

export interface AIProvider {
  id: string;
  name: string;
  enabled: boolean;
  apiKey?: string;
  endpoint?: string;
  models: string[];
  type: 'text' | 'image' | 'both';
  requiresAuth: boolean;
}

export interface MCPServer {
  id: string;
  name: string;
  endpoint: string;
  enabled: boolean;
  description?: string;
  capabilities: string[];
}

export interface Settings {
  theme: Theme;
  fontSize: FontSize;
  animationSpeed: AnimationSpeed;
  reduceMotion: boolean;
  chatWidth: ChatWidth;
  bubbleShape: BubbleShape;
  showTimestamps: boolean;
  defaultModel: string;
  defaultProvider: string;
  textApiEndpoint: string;
  imageApiEndpoint: string;
  customApis: CustomApi[];
  aiProviders: AIProvider[];
  mcpServers: MCPServer[];
  puterIntegration: {
    enabled: boolean;
    useKVStorage: boolean;
    useFileSystem: boolean;
    useAI: boolean;
  };
  customization: {
    primaryColor: string;
    accentColor: string;
    fontFamily: string;
    messageSpacing: 'compact' | 'normal' | 'relaxed';
    codeTheme: 'github' | 'monokai' | 'dracula';
  };
}

export interface CustomApi {
  id: string;
  name: string;
  endpoint: string;
  type: 'text' | 'image' | 'mcp';
  enabled: boolean;
  apiKey?: string;
}

// Extended model list with multiple providers
export const AI_PROVIDERS = {
  pollinations: {
    name: 'Pollinations AI',
    models: ['OpenAI', 'Mistral', 'Claude', 'Flux', 'Turbo'],
    type: 'both' as const,
  },
  puter: {
    name: 'Puter AI',
    models: ['GPT-4', 'Claude-3', 'Llama-3'],
    type: 'text' as const,
  },
  openai: {
    name: 'OpenAI',
    models: ['GPT-4', 'GPT-4-Turbo', 'GPT-3.5-Turbo', 'DALL-E-3'],
    type: 'both' as const,
  },
  anthropic: {
    name: 'Anthropic',
    models: ['Claude-3-Opus', 'Claude-3-Sonnet', 'Claude-3-Haiku'],
    type: 'text' as const,
  },
  google: {
    name: 'Google',
    models: ['Gemini-Pro', 'Gemini-Pro-Vision', 'PaLM-2'],
    type: 'both' as const,
  },
  cohere: {
    name: 'Cohere',
    models: ['Command', 'Command-Light', 'Command-Nightly'],
    type: 'text' as const,
  },
  groq: {
    name: 'Groq',
    models: ['Llama-3-70B', 'Llama-3-8B', 'Mixtral-8x7B'],
    type: 'text' as const,
  },
  huggingface: {
    name: 'Hugging Face',
    models: ['Mistral-7B', 'Falcon-40B', 'Stable-Diffusion-XL'],
    type: 'both' as const,
  },
} as const;

export const MODELS = ['OpenAI', 'Mistral', 'Claude', 'Flux', 'GPT-4', 'Gemini-Pro'] as const;
export type Model = typeof MODELS[number];
