import { Message } from '@/types/chat';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { useState } from 'react';
import { Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { User, Bot } from 'lucide-react';

interface ChatMessageProps {
  message: Message;
  showTimestamps: boolean;
  bubbleShape: 'rounded' | 'square';
}

const CodeBlock = ({ code, language }: { code: string; language?: string }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    toast.success('Code copied to clipboard');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative group my-2">
      <div className="flex items-center justify-between bg-muted px-3 py-1 rounded-t-md border border-border">
        <span className="text-xs text-muted-foreground font-mono">{language || 'code'}</span>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleCopy}
          className="h-6 px-2"
        >
          {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
        </Button>
      </div>
      <pre className="bg-secondary p-4 rounded-b-md overflow-x-auto border border-t-0 border-border">
        <code className="text-sm font-mono">{code}</code>
      </pre>
    </div>
  );
};

const renderMessageContent = (content: string) => {
  const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g;
  const inlineCodeRegex = /`([^`]+)`/g;
  
  const parts: JSX.Element[] = [];
  let lastIndex = 0;
  let match;

  // Process code blocks
  const processedContent = content.replace(codeBlockRegex, (match, language, code) => {
    return `__CODE_BLOCK_${parts.length}__${parts.push(<CodeBlock key={parts.length} code={code.trim()} language={language} />)}__`;
  });

  // Split by code block placeholders
  const segments = processedContent.split(/(__CODE_BLOCK_\d+__\d+__)/);
  
  return segments.map((segment, index) => {
    const codeBlockMatch = segment.match(/__CODE_BLOCK_(\d+)__\d+__/);
    if (codeBlockMatch) {
      return parts[parseInt(codeBlockMatch[1])];
    }
    
    // Handle inline code
    const inlineParts = segment.split(inlineCodeRegex);
    return (
      <span key={index}>
        {inlineParts.map((part, i) => {
          if (i % 2 === 1) {
            return (
              <code key={i} className="bg-secondary px-1.5 py-0.5 rounded text-sm font-mono">
                {part}
              </code>
            );
          }
          return part;
        })}
      </span>
    );
  });
};

export function ChatMessage({ message, showTimestamps, bubbleShape }: ChatMessageProps) {
  const isUser = message.role === 'user';

  return (
    <div className={cn("flex gap-3 animate-fade-in", isUser ? "justify-end" : "justify-start")}>
      {!isUser && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-primary flex items-center justify-center">
          <Bot className="w-5 h-5 text-primary-foreground" />
        </div>
      )}
      
      <div className={cn("flex flex-col max-w-[80%]", isUser && "items-end")}>
        <div
          className={cn(
            "px-4 py-3 shadow-md transition-smooth",
            bubbleShape === 'rounded' ? "rounded-2xl" : "rounded-md",
            isUser
              ? "bg-gradient-primary text-primary-foreground"
              : "bg-card text-card-foreground border border-border"
          )}
        >
          {message.type === 'image' && message.imageUrl ? (
            <img 
              src={message.imageUrl} 
              alt="Generated content" 
              className={cn("max-w-full h-auto", bubbleShape === 'rounded' ? "rounded-xl" : "rounded")}
            />
          ) : (
            <div className="whitespace-pre-wrap break-words">
              {renderMessageContent(message.content)}
            </div>
          )}
          
          {message.attachments && message.attachments.length > 0 && (
            <div className="mt-2 space-y-1">
              {message.attachments.map((attachment) => (
                <div key={attachment.id} className="text-xs opacity-80">
                  📎 {attachment.file.name}
                </div>
              ))}
            </div>
          )}
        </div>
        
        {showTimestamps && (
          <span className="text-xs text-muted-foreground mt-1 px-2">
            {format(new Date(message.timestamp), 'HH:mm')}
          </span>
        )}
      </div>

      {isUser && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
          <User className="w-5 h-5 text-secondary-foreground" />
        </div>
      )}
    </div>
  );
}
