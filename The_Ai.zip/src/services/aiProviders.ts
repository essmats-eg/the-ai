import { AIProvider } from '@/types/chat';

interface GenerateTextParams {
  prompt: string;
  model: string;
  provider: AIProvider;
}

interface GenerateImageParams {
  prompt: string;
  model: string;
  provider: AIProvider;
}

export class AIProviderService {
  // Pollinations AI
  static async generateTextPollinations(prompt: string, model: string, endpoint: string): Promise<string> {
    const url = `${endpoint}/${encodeURIComponent(prompt)}?model=${model.toLowerCase()}`;
    const response = await fetch(url);
    return await response.text();
  }

  static async generateImagePollinations(prompt: string, model: string, endpoint: string): Promise<string> {
    return `${endpoint}/${encodeURIComponent(prompt)}?model=${model.toLowerCase()}`;
  }

  // Puter AI
  static async generateTextPuter(prompt: string, model: string): Promise<string> {
    if (typeof window !== 'undefined' && (window as any).puter) {
      try {
        const puter = (window as any).puter;
        const response = await puter.ai.chat(prompt, {
          model: model.toLowerCase(),
        });
        return response.message?.content || response.toString();
      } catch (error) {
        console.error('Puter AI error:', error);
        throw new Error('Failed to generate text with Puter AI');
      }
    }
    throw new Error('Puter SDK not available');
  }

  // OpenAI
  static async generateTextOpenAI(prompt: string, model: string, apiKey: string): Promise<string> {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: model.toLowerCase(),
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0]?.message?.content || 'No response';
  }

  static async generateImageOpenAI(prompt: string, apiKey: string): Promise<string> {
    const response = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'dall-e-3',
        prompt: prompt,
        n: 1,
        size: '1024x1024',
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.data[0]?.url || '';
  }

  // Anthropic Claude
  static async generateTextAnthropic(prompt: string, model: string, apiKey: string): Promise<string> {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: model.toLowerCase(),
        max_tokens: 4096,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      throw new Error(`Anthropic API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.content[0]?.text || 'No response';
  }

  // Google Gemini
  static async generateTextGoogle(prompt: string, model: string, apiKey: string): Promise<string> {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
        }),
      }
    );

    if (!response.ok) {
      throw new Error(`Google API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.candidates[0]?.content?.parts[0]?.text || 'No response';
  }

  // Cohere
  static async generateTextCohere(prompt: string, model: string, apiKey: string): Promise<string> {
    const response = await fetch('https://api.cohere.ai/v1/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: model.toLowerCase(),
        prompt: prompt,
        max_tokens: 2000,
      }),
    });

    if (!response.ok) {
      throw new Error(`Cohere API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.generations[0]?.text || 'No response';
  }

  // Groq
  static async generateTextGroq(prompt: string, model: string, apiKey: string): Promise<string> {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: model.toLowerCase(),
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      throw new Error(`Groq API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0]?.message?.content || 'No response';
  }

  // Hugging Face
  static async generateTextHuggingFace(prompt: string, model: string, apiKey: string): Promise<string> {
    const response = await fetch(
      `https://api-inference.huggingface.co/models/${model}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({ inputs: prompt }),
      }
    );

    if (!response.ok) {
      throw new Error(`Hugging Face API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data[0]?.generated_text || 'No response';
  }

  // Main router function
  static async generateText({ prompt, model, provider }: GenerateTextParams): Promise<string> {
    switch (provider.id) {
      case 'pollinations':
        return this.generateTextPollinations(prompt, model, provider.endpoint || 'https://text.pollinations.ai');
      
      case 'puter':
        return this.generateTextPuter(prompt, model);
      
      case 'openai':
        if (!provider.apiKey) throw new Error('OpenAI API key required');
        return this.generateTextOpenAI(prompt, model, provider.apiKey);
      
      case 'anthropic':
        if (!provider.apiKey) throw new Error('Anthropic API key required');
        return this.generateTextAnthropic(prompt, model, provider.apiKey);
      
      case 'google':
        if (!provider.apiKey) throw new Error('Google API key required');
        return this.generateTextGoogle(prompt, model, provider.apiKey);
      
      case 'cohere':
        if (!provider.apiKey) throw new Error('Cohere API key required');
        return this.generateTextCohere(prompt, model, provider.apiKey);
      
      case 'groq':
        if (!provider.apiKey) throw new Error('Groq API key required');
        return this.generateTextGroq(prompt, model, provider.apiKey);
      
      case 'huggingface':
        if (!provider.apiKey) throw new Error('Hugging Face API key required');
        return this.generateTextHuggingFace(prompt, model, provider.apiKey);
      
      default:
        throw new Error(`Unknown provider: ${provider.id}`);
    }
  }

  static async generateImage({ prompt, model, provider }: GenerateImageParams): Promise<string> {
    switch (provider.id) {
      case 'pollinations':
        return this.generateImagePollinations(prompt, model, provider.endpoint || 'https://image.pollinations.ai/prompt');
      
      case 'openai':
        if (!provider.apiKey) throw new Error('OpenAI API key required');
        return this.generateImageOpenAI(prompt, provider.apiKey);
      
      default:
        throw new Error(`Image generation not supported for provider: ${provider.id}`);
    }
  }
}
