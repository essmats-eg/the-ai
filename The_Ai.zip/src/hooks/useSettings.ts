import { useLocalStorage } from './useLocalStorage';
import { Settings } from '@/types/chat';

const defaultSettings: Settings = {
  theme: 'system',
  fontSize: 'medium',
  animationSpeed: 'normal',
  reduceMotion: false,
  chatWidth: 'medium',
  bubbleShape: 'rounded',
  showTimestamps: true,
  defaultModel: 'OpenAI',
  defaultProvider: 'pollinations',
  textApiEndpoint: 'https://text.pollinations.ai',
  imageApiEndpoint: 'https://image.pollinations.ai/prompt',
  customApis: [],
  aiProviders: [
    {
      id: 'pollinations',
      name: 'Pollinations AI',
      enabled: true,
      models: ['OpenAI', 'Mistral', 'Claude', 'Flux', 'Turbo'],
      type: 'both',
      requiresAuth: false,
    },
    {
      id: 'puter',
      name: 'Puter AI',
      enabled: true,
      models: ['GPT-4', 'Claude-3', 'Llama-3'],
      type: 'text',
      requiresAuth: false,
    },
  ],
  mcpServers: [],
  puterIntegration: {
    enabled: true,
    useKVStorage: false,
    useFileSystem: false,
    useAI: true,
  },
  customization: {
    primaryColor: '#8B5CF6',
    accentColor: '#EC4899',
    fontFamily: 'system-ui',
    messageSpacing: 'normal',
    codeTheme: 'github',
  },
};

export function useSettings() {
  return useLocalStorage<Settings>('chat-settings', defaultSettings);
}
