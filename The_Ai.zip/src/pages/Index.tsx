import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { ChatMessage } from '@/components/ChatMessage';
import { ChatInput } from '@/components/ChatInput';
import { SettingsDialog } from '@/components/SettingsDialog';
import { Message, GenerationType, AttachedFile } from '@/types/chat';
import { useSettings } from '@/hooks/useSettings';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { Undo, Trash2, Download } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { AIProviderService } from '@/services/aiProviders';

const Index = () => {
  const [settings, setSettings] = useSettings();
  const [messages, setMessages] = useLocalStorage<Message[]>('chat-messages', []);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const root = document.documentElement;
    if (settings.theme === 'dark') {
      root.classList.add('dark');
    } else if (settings.theme === 'light') {
      root.classList.remove('dark');
    } else {
      const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      root.classList.toggle('dark', isDark);
    }

    // Apply custom colors
    root.style.setProperty('--primary', settings.customization.primaryColor);
    root.style.setProperty('--accent', settings.customization.accentColor);
  }, [settings.theme, settings.customization]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Save to Puter KV Storage if enabled
  useEffect(() => {
    if (settings.puterIntegration.enabled && settings.puterIntegration.useKVStorage) {
      const saveToPuter = async () => {
        try {
          if (typeof window !== 'undefined' && (window as any).puter) {
            await (window as any).puter.kv.set('chat-messages', JSON.stringify(messages));
          }
        } catch (error) {
          console.error('Failed to save to Puter KV:', error);
        }
      };
      saveToPuter();
    }
  }, [messages, settings.puterIntegration]);

  const handleSendMessage = async (
    content: string,
    type: GenerationType,
    attachments: AttachedFile[],
    model: string
  ) => {
    const userMessage: Message = {
      id: Math.random().toString(36).substr(2, 9),
      role: 'user',
      content,
      timestamp: new Date(),
      type,
      attachments,
      provider: settings.defaultProvider,
      model,
    };

    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      let response: string | undefined;
      let imageUrl: string | undefined;

      // Find the active provider
      const provider = settings.aiProviders.find(
        p => p.id === settings.defaultProvider && p.enabled
      );

      if (!provider) {
        throw new Error('No active provider found. Please enable a provider in settings.');
      }

      if (type === 'text') {
        // Check if we should use Puter AI
        if (settings.puterIntegration.enabled && settings.puterIntegration.useAI && provider.id === 'puter') {
          response = await AIProviderService.generateText({ prompt: content, model, provider });
        } else if (provider.id === 'pollinations') {
          // Use Pollinations
          response = await AIProviderService.generateText({
            prompt: content,
            model,
            provider: {
              ...provider,
              endpoint: settings.textApiEndpoint,
            },
          });
        } else {
          // Use other providers
          response = await AIProviderService.generateText({ prompt: content, model, provider });
        }
      } else {
        // Image generation
        if (provider.id === 'pollinations') {
          imageUrl = await AIProviderService.generateImage({
            prompt: content,
            model,
            provider: {
              ...provider,
              endpoint: settings.imageApiEndpoint,
            },
          });
          response = 'Image generated successfully';
        } else {
          imageUrl = await AIProviderService.generateImage({ prompt: content, model, provider });
          response = 'Image generated successfully';
        }
      }

      const assistantMessage: Message = {
        id: Math.random().toString(36).substr(2, 9),
        role: 'assistant',
        content: response || 'No response received',
        timestamp: new Date(),
        type,
        imageUrl,
        provider: provider.name,
        model,
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Save to Puter File System if enabled
      if (settings.puterIntegration.enabled && settings.puterIntegration.useFileSystem) {
        try {
          if (typeof window !== 'undefined' && (window as any).puter) {
            const chatLog = `User: ${content}\nAssistant: ${response}\n\n`;
            await (window as any).puter.fs.write(
              'chat-history.txt',
              chatLog,
              { append: true }
            );
          }
        } catch (error) {
          console.error('Failed to save to Puter FS:', error);
        }
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to get response from AI');
      console.error('AI Error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleExportChat = () => {
    const exportText = messages
      .map(msg => {
        const provider = msg.provider ? ` [${msg.provider}${msg.model ? ` - ${msg.model}` : ''}]` : '';
        return `${msg.role === 'user' ? 'User' : 'Assistant'}${provider}: ${msg.content}`;
      })
      .join('\n\n');

    const blob = new Blob([exportText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chat-export-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Chat exported successfully');
  };

  const handleSaveToPuter = async () => {
    if (typeof window !== 'undefined' && (window as any).puter) {
      try {
        const exportText = messages
          .map(msg => `${msg.role === 'user' ? 'User' : 'Assistant'}: ${msg.content}`)
          .join('\n\n');
        
        await (window as any).puter.fs.write(
          `chat-${new Date().toISOString().split('T')[0]}.txt`,
          exportText
        );
        toast.success('Chat saved to Puter Drive');
      } catch (error) {
        toast.error('Failed to save to Puter Drive');
        console.error('Puter save error:', error);
      }
    } else {
      toast.error('Puter integration not available');
    }
  };

  const handleUndo = () => {
    if (messages.length === 0) return;
    setMessages(prev => prev.slice(0, -1));
    toast.success('Last message removed');
  };

  const handleClearChat = () => {
    setMessages([]);
    toast.success('Chat cleared');
  };

  const chatWidthClass = {
    compact: 'max-w-[800px]',
    medium: 'max-w-[1000px]',
    wide: 'max-w-[1200px]',
  }[settings.chatWidth];

  const fontSizeClass = {
    small: 'text-sm',
    medium: 'text-base',
    large: 'text-lg',
  }[settings.fontSize];

  const messageSpacingClass = {
    compact: 'space-y-3',
    normal: 'space-y-6',
    relaxed: 'space-y-8',
  }[settings.customization.messageSpacing];

  return (
    <div className="min-h-screen bg-gradient-bg flex flex-col">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
              DeepDown AI
            </h1>
            <p className="text-xs text-muted-foreground">
              Powered by {settings.aiProviders.filter(p => p.enabled).length} AI providers
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="icon" onClick={handleUndo} title="Undo last message">
              <Undo className="w-5 h-5" />
            </Button>
            <Button variant="outline" size="icon" onClick={handleClearChat} title="Clear chat">
              <Trash2 className="w-5 h-5" />
            </Button>
            {settings.puterIntegration.enabled && settings.puterIntegration.useFileSystem && (
              <Button variant="outline" size="icon" onClick={handleSaveToPuter} title="Save to Puter Drive">
                <Download className="w-5 h-5" />
              </Button>
            )}
            <SettingsDialog settings={settings} onSettingsChange={setSettings} />
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto py-8">
        <div className={cn("container mx-auto px-4", chatWidthClass, fontSizeClass)}>
          {messages.length === 0 ? (
            <div className="flex items-center justify-center h-[60vh] animate-fade-in">
              <div className="text-center space-y-4">
                <div className="w-20 h-20 mx-auto bg-gradient-primary rounded-full flex items-center justify-center shadow-xl">
                  <span className="text-3xl">🤖</span>
                </div>
                <h2 className="text-3xl font-bold">Welcome to DeepDown AI</h2>
                <p className="text-muted-foreground max-w-md">
                  Your advanced AI chat interface with multiple providers, custom integrations,
                  and Puter cloud features. Configure your experience in settings.
                </p>
                <div className="flex flex-wrap gap-2 justify-center mt-4">
                  {settings.aiProviders.filter(p => p.enabled).map(provider => (
                    <span key={provider.id} className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full">
                      {provider.name}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className={messageSpacingClass}>
              {messages.map((message) => (
                <ChatMessage
                  key={message.id}
                  message={message}
                  showTimestamps={settings.showTimestamps}
                  bubbleShape={settings.bubbleShape}
                />
              ))}
              {isLoading && (
                <div className="flex items-center gap-2 text-muted-foreground animate-pulse">
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>
      </main>

      <ChatInput
        onSendMessage={handleSendMessage}
        onExportChat={handleExportChat}
        disabled={isLoading}
      />
    </div>
  );
};

export default Index;
