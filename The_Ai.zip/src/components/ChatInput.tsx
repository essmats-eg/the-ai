import { useState, useRef, KeyboardEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Send, Paperclip, Download, Shuffle } from 'lucide-react';
import { GenerationType, AttachedFile, MODELS, Model } from '@/types/chat';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ChatInputProps {
  onSendMessage: (content: string, type: GenerationType, attachments: AttachedFile[], model: string) => void;
  onExportChat: () => void;
  disabled?: boolean;
}

export function ChatInput({ onSendMessage, onExportChat, disabled }: ChatInputProps) {
  const [input, setInput] = useState('');
  const [generationType, setGenerationType] = useState<GenerationType>('text');
  const [selectedModel, setSelectedModel] = useState<Model>('OpenAI');
  const [attachments, setAttachments] = useState<AttachedFile[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSend = () => {
    if (!input.trim() && attachments.length === 0) return;
    onSendMessage(input, generationType, attachments, selectedModel);
    setInput('');
    setAttachments([]);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles: AttachedFile[] = [];

    files.forEach(file => {
      if (file.size > 10 * 1024 * 1024) {
        toast.error(`${file.name} exceeds 10MB limit`);
        return;
      }

      const attachedFile: AttachedFile = {
        id: Math.random().toString(36).substr(2, 9),
        file,
      };

      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onloadend = () => {
          attachedFile.preview = reader.result as string;
        };
        reader.readAsDataURL(file);
      }

      validFiles.push(attachedFile);
    });

    setAttachments(prev => [...prev, ...validFiles]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments(prev => prev.filter(a => a.id !== id));
  };

  const shuffleModel = () => {
    const randomModel = MODELS[Math.floor(Math.random() * MODELS.length)];
    setSelectedModel(randomModel);
    toast.success(`Model changed to ${randomModel}`);
  };

  return (
    <div className="border-t border-border bg-card/50 backdrop-blur-sm p-4">
      <div className="max-w-4xl mx-auto space-y-3">
        <div className="flex gap-2 items-center flex-wrap">
          <Select value={generationType} onValueChange={(v) => setGenerationType(v as GenerationType)}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="text">Text</SelectItem>
              <SelectItem value="image">Image</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedModel} onValueChange={(v) => setSelectedModel(v as Model)}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {MODELS.map(model => (
                <SelectItem key={model} value={model}>{model}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button variant="outline" size="icon" onClick={shuffleModel} title="Shuffle model">
            <Shuffle className="w-4 h-4" />
          </Button>

          <div className="flex-1" />

          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={handleFileChange}
            accept=".html,.htm,.tsx,.ts,.jsx,.js,.json,.css,.scss,.sass,.less,.xml,.svg,.txt,.md,.yaml,.yml,.toml,.ini,.conf,.config,.py,.rb,.php,.java,.c,.cpp,.h,.hpp,.cs,.go,.rs,.swift,.kt,.vue,.astro,.svelte"
          />
          <Button variant="outline" size="icon" onClick={() => fileInputRef.current?.click()} title="Attach files">
            <Paperclip className="w-4 h-4" />
          </Button>

          <Button variant="outline" size="icon" onClick={onExportChat} title="Export chat">
            <Download className="w-4 h-4" />
          </Button>
        </div>

        {attachments.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {attachments.map(attachment => (
              <div
                key={attachment.id}
                className="flex items-center gap-2 bg-secondary px-3 py-2 rounded-lg text-sm"
              >
                {attachment.preview && (
                  <img src={attachment.preview} alt="" className="w-8 h-8 object-cover rounded" />
                )}
                <span className="max-w-[150px] truncate">{attachment.file.name}</span>
                <button
                  onClick={() => removeAttachment(attachment.id)}
                  className="text-muted-foreground hover:text-foreground"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="flex gap-2">
          <Textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type your message... (Shift+Enter for new line, supports code blocks with ```)"
            className="min-h-[60px] max-h-[400px] resize-none"
            disabled={disabled}
            maxLength={100000}
          />
          <Button
            onClick={handleSend}
            disabled={disabled || (!input.trim() && attachments.length === 0)}
            size="icon"
            className="h-[60px] w-[60px] bg-gradient-primary hover:opacity-90"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
